﻿// FinalProjectTemplage.cpp : Defines the entry point for the application.
//

using namespace std;

#include <SFML/Window.hpp>
#include <SFML/Graphics.hpp>
#include <SFML/Audio.hpp>
#include <SFML/System.hpp>
#include <iostream>
#include <chrono>
#include <thread>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>  
#include <string>

bool win(bool[]);

int main()
{
    sf::RenderWindow window(sf::VideoMode(800, 800), "Card Game");
    start:
    sf::Texture texture[21];
    if (!texture[0].loadFromFile("background.jpg")) {
        cout << "File not loaded";
        return -1;
    }
    int width = 160;
    int length = 200;
    char* cards[20] = { "A.png", "B.png", "C.png", "D.png", "E.png", "F.png", "G.png", "H.png", "I.png", "J.png",
    "A.png", "B.png", "C.png", "D.png", "E.png", "F.png", "G.png", "H.png", "I.png", "J.png"};
   
    bool verified1[20] = { false };
    bool verified2[20] = { false };

    sf::Sprite sprite[40];
    sf::SoundBuffer buffer[3];
    sf::Sound sound[3];
    char* sounds[3] = { "hitmatch.wav", "no.wav", "win.wav" };
    for (int i = 0; i < 3; i++) {
        if (!buffer[i].loadFromFile(sounds[i])) {
            cout << "Audio load failed" << endl;
            return -1;
        }
        sound[i].setBuffer(buffer[i]);
    }
    srand(time(NULL));

    for (int i = 0; i < 20; i++) {
        sprite[i].setTexture(texture[0]);
    }

    for (int i = 20; i < 40; i++) {
        if (!texture[(i - 20) / 2 + 1].loadFromFile(cards[(i - 20) / 2])) {
            cout << "File not loaded";
            return -1;
        }
        sprite[i].setTexture(texture[(i - 20) / 2 + 1]);
    }

    // Shuffle cards
    for (int i = 0; i < 20; i++) {
        int s1 = 0;
        int s2 = 0;
        while (s1 == s2) {
            s1 = rand() % 20;
            s2 = rand() % 20;
        }
        swap(sprite[s1 + 20], sprite[s2 + 20]);
    }
    int index1 = 0;
    int index2 = 0;
    int counter = 0;
    bool veri = false;
    // run the program as long as the window is open
    while (window.isOpen())
    {
        // check all the window's events that were triggered since the last iteration of the loop
        sf::Event event;

        while (window.pollEvent(event))
        {
            
            // "close requested" event: we close the window
            if (event.type == sf::Event::Closed)
                window.close();

            for (int i = 0; i < 20; i++) {
                sprite[i].setPosition(sf::Vector2f(width * (i % 5), length * ((i / 5) % 4)));
                sprite[i + 20].setPosition(sf::Vector2f(width * (i % 5), length * ((i / 5)% 4)));
            }

            if (sf::Mouse::isButtonPressed(sf::Mouse::Left)) {
                this_thread::sleep_for(chrono::milliseconds(300));
                sf::Vector2i localPosition = sf::Mouse::getPosition(window);
                sf::Vector2f floatPosition(localPosition.x, localPosition.y);
                //cout << "Clicked on row " << localPosition.y / length << ", col " << localPosition.x / width << endl;
                index1 = 5 * (localPosition.y / length) + localPosition.x / width;
                //cout << "Card index " << index1 << endl;
                //cout << "Texture " << sprite[index1 + 20].getTexture() << endl;
                verified1[index1] = true;
                counter++;
                if (counter % 2 == 0) {
                    if (sprite[index1 + 20].getTexture() == sprite[index2 + 20].getTexture()) {
                        verified2[index1] = true;
                        verified2[index2] = true;
                        // Play hit sound                     
                        sound[0].play();

                    }
                    else {
                        // Play sad sound
                        sound[1].play();
                    }
                    veri = true;
                }
                else {
                    veri = false;
 
                }
                cout << "step: " << counter << endl;
                index2 = index1;
            }
        }
        window.clear(sf::Color::White);

        if (veri) {
            cout << "verifying\n";
            for (int i = 0; i < 20; i++) {
                if (verified1[i]) {
                    window.draw(sprite[i + 20]);
                    verified1[i] = verified2[i];
                }
                else {
                    window.draw(sprite[i]);
                }
            }
        }
        else {
            for (int i = 0; i < 20; i++) {
                if (verified2[i]) {
                    sprite[i + 20].setColor(sf::Color::Transparent);
                }
                else if (verified1[i]) {
                    window.draw(sprite[i + 20]);
                }
                else {
                    window.draw(sprite[i]);
                }
            }
        }
        window.display();
        if (veri) {
            this_thread::sleep_for(chrono::milliseconds(3000));
            veri = false;
        }
        if (win(verified2)) {
            cout << "VICTORY!\n" << "You used " << counter << " steps" << endl;
            // Play victory sound
            sound[2].play();
            this_thread::sleep_for(chrono::milliseconds(4000));
            // condition
            /*
            sf::Texture textture1;
             if(!textture1.loadFromFile("restart.png")){
                cout << "Load restart failed..." << endl;
            }
            sf::Sprite sprite1;
            sprite1.setTexture(textture1);
            window.draw(sprite1);
             if (sf::Mouse::isButtonPressed(sf::Mouse::Left))
            {
                goto start;

            }
            */
            string choice;
            cout << "Do you want to play again? Press Y or y to continue: " << endl;
            cin >> choice;
            if (choice == "Y " || choice == "y") {
                sf::Texture textture1;
                if (!textture1.loadFromFile("restart.png")) {
                    cout << "Load restart failed..." << endl;
                }
                sf::Sprite sprite1;
                sprite1.setTexture(textture1);
                window.draw(sprite1);
                goto start;
            }
            else {
                return 0;
            }
        }
    }
    return 0;
}

bool win(bool verified[20]) {
    for (int i = 0; i < 20; i++) {
        if (!verified[i]){
            return verified[i];
        }
    }
    return true;
}